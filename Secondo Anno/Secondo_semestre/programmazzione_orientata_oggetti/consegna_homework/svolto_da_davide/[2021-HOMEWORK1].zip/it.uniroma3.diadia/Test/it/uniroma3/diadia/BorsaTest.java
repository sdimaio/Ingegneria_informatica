package it.uniroma3.diadia;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.giocatore.Borsa;

public class BorsaTest {
	private Attrezzo attrezzo;
	private Borsa bag;

	@Before
	public void setUp(){
		attrezzo = new Attrezzo("martello", 5);
		bag = new Borsa();

	}
	@Test
	public void testAddAttrezzo() {
		assertTrue("funzionamento non normale, non si riesce ad aggiungere un attrezzo", bag.addAttrezzo(attrezzo));
	}

	@Test
	public void testAddAttrezzoBorsaPiena() {
		attrezzo = new Attrezzo("forbice", 1);
		for(int i = 0; i < 10; i++) {
			bag.addAttrezzo(attrezzo);
		}
		assertFalse("oggetto aggiunto in borsapiena", bag.addAttrezzo(attrezzo));
	}

	@Test
	public void testAddAttrezzoBorsaPesante() {
		attrezzo = new Attrezzo("vanga", 10);
		bag.addAttrezzo(attrezzo);

		assertFalse("", bag.addAttrezzo(attrezzo));
	}

	@Test
	public void testGetPeso() {
		assertEquals(0,bag.getPeso());
	}

	@Test
	public void testGetPesoUnoMax() {
		attrezzo = new Attrezzo("vanga", 10);
			bag.addAttrezzo(attrezzo);
		assertEquals(10, bag.getPeso());
	}
	@Test
	public void testGetPesoDieciAttr() {
		attrezzo = new Attrezzo("forbice", 1);
		for(int i = 0; i < 10; i++) {
			bag.addAttrezzo(attrezzo);
		}
		assertEquals(10, bag.getPeso());
	}
	
	@Test
	public void testRemoveAttrezzo() {
		assertNull("",bag.removeAttrezzo("martello"));
	}
	
	@Test
	public void testRemoveAttrezzoUnico() {
		bag.addAttrezzo(attrezzo);
		assertEquals(attrezzo, bag.removeAttrezzo("martello"));
	}
	
	@Test
	public void testRemoveAttrezzoDaDieci() {
		attrezzo = new Attrezzo("forbice", 1);
		for(int i = 0; i < 10; i++) {
			bag.addAttrezzo(attrezzo);
		}
		assertEquals(attrezzo, bag.removeAttrezzo("forbice"));
	}

}
