package it.uniroma3.diadia;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.giocatore.Borsa;

public class GiocatoreTest {
	private Partita partita;
	private Borsa bag;

	@Before
	public void setUp(){
		partita = new Partita();
	}
	
	@Test
	public void testGetCfu() {
		assertEquals(20,partita.ciocatore.getCfu());
	}
	
	//i test del setCfu() sono omessi perchè già testati nei test del getCfu()
	@Test
	public void testGetCfuMaxInteger() {
		partita.ciocatore.setCfu(Integer.MAX_VALUE);
		assertEquals(Integer.MAX_VALUE,partita.ciocatore.getCfu());
	}
	
	
	@Test
	public void testGetBorsa() {
		bag = new Borsa();
		assertFalse("",bag == partita.ciocatore.getBorsa());
	}

	@Test
	public void testGetBorsaUguali() {
		bag = partita.ciocatore.getBorsa();
		assertTrue("",bag == partita.ciocatore.getBorsa());
	}
}
