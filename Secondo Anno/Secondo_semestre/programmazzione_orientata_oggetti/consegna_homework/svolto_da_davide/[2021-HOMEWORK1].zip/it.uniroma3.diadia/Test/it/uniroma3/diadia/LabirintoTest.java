package it.uniroma3.diadia;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.Stanza;

public class LabirintoTest {

	private Labirinto lab;
	private Stanza salone;
	private Stanza stanza;

	@Before
	public void setUp(){
		lab = new Labirinto();
	}
	
	@Test
	public void testGetStanzaVincenteVero() {
		lab.creaStanze();
		assertEquals("Biblioteca",lab.getStanzaVincente().getNome());
	}

	@Test
	public void testGetStanzaVincenteFalso() {
		assertNull("",lab.getStanzaVincente());
	}
	
	@Test
	public void testGetStanzaCorrente() {
		lab.creaStanze();
		salone = new Stanza("Salone");
		lab.setStanzaCorrente(salone);
		assertEquals(salone,lab.getStanzaCorrente());
	}
	
	@Test
	public void testSetStanzaCorrenteNotEquals() {
		lab.creaStanze();
		salone = lab.getStanzaCorrente();
		stanza = new Stanza("Garage");
		lab.setStanzaCorrente(stanza);
		assertNotEquals(salone, lab.getStanzaCorrente());
	}
	
	@Test
	public void testSetStanzaCorrenteAtrio() {
		lab.creaStanze();
		assertEquals("Atrio", lab.getStanzaCorrente().getNome());
	}

}
