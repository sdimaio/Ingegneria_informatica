package it.uniroma3.diadia;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class PartitaTest {
	private Partita partita;
	
	//test realizzati prima di introdurre la classe Giocatore
	@Before
	public void setUp() {
		partita = new Partita();
		
		//@Test
//	public void testGetAttrezzo() {
//		this.n11 = new Stanza("n11");
//		Attrezzo vanga = new Attrezzo("vanga", 5);
//		n11.addAttrezzo(vanga);
//		assertNull("bho", n11.getAttrezzo("martello"));
//	}
//	
	}
	
	@Test
	public void testVintaFalse() {
		assertFalse("Ritorna true se inizializzato a due stanze uguali", partita.labirintoCorrente.getStanzaCorrente()== partita.labirintoCorrente.getStanzaVincente());
	}
	
	@Test
	public void testVintaTrue() {
		partita.labirintoCorrente.setStanzaCorrente(partita.labirintoCorrente.getStanzaVincente());
		assertTrue("Ritorna false se le due stanze sono inizializzate a stanze diverse.",partita.labirintoCorrente.getStanzaCorrente()== partita.labirintoCorrente.getStanzaVincente());
	}

	@Test
	public void testVintaNull() {
		partita.labirintoCorrente.setStanzaCorrente(null);
		assertFalse("Ritorna true se inizializziamo stanza corrente e stanza vincente a null.",partita.labirintoCorrente.getStanzaCorrente()== partita.labirintoCorrente.getStanzaVincente());
	}

	@Test
	public void testIsFinita() {
		partita.labirintoCorrente.setStanzaCorrente(partita.labirintoCorrente.getStanzaVincente());
		partita.setFinita();
		partita.ciocatore.setCfu(0);
		assertTrue("ritorna false se uno fra setFinita, setCfu o la stanza corrente sono false",partita.isFinita());
	}
	
	@Test
	public void testIsFinitaNon() {
		partita.labirintoCorrente.setStanzaCorrente(null);
		partita.ciocatore.setCfu(20);
		assertFalse("",partita.isFinita());
	}
		
	@Test
	public void testSetFinita() {
		partita.labirintoCorrente.setStanzaCorrente(null);
		partita.setFinita();
		partita.ciocatore.setCfu(0);

		assertTrue("ritorna false se setFinita non funziona", partita.isFinita());
	}

}
