package it.uniroma3.diadia;

import static org.junit.Assert.*;

import org.junit.Test;

import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class StanzaTest {
	
	public Stanza stanza;

	/*@Before
	public void setUp() {
		stanzaVuota = new Stanza("");

	}
	*/
    
	@Test
	public void testGetNome() {
		this.stanza = new Stanza("atrio");
		assertEquals("atrio", stanza.getNome());
	}
	
	@Test
	public void testGetNomeVuoto() {
		this.stanza = new Stanza("");
		assertEquals("", stanza.getNome());
	}

	@Test
	public void testGetNomeNoStanza() {
		this.stanza = new Stanza(null);
		assertEquals(null, stanza.getNome());
	}

	@Test
	public void testAddAttrezzo() {
		this.stanza = new Stanza("atrio");
		Attrezzo martello = new Attrezzo("martello", 1000);
		assertTrue("Aggiunto il martello", stanza.addAttrezzo(martello));
	}

	@Test
	public void testAddAttrezzoFalse() {
		this.stanza = new Stanza("atrio");
		Attrezzo martello = new Attrezzo("martello", 1000);
		for(int i = 0; i<100;i++) {
			stanza.addAttrezzo(martello);
		}
		assertFalse("L'aggiunta avviene perchè l'array è pieno!", stanza.addAttrezzo(martello));
	}

	@Test
	public void testAddAttrezzoNull() {
		this.stanza = new Stanza("atrio");
		assertTrue("L'aggiunta di null è avvenuta!", stanza.addAttrezzo(null));
	}
	
	@Test
	public void testGetAttrezzo() {
		this.stanza = new Stanza("atrio");
		Attrezzo martello = new Attrezzo("martello", 5);
		stanza.addAttrezzo(martello);
		assertNull("piccone", stanza.getAttrezzo("freccia"));
	}
	

}
