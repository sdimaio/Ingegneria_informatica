package it.uniroma3.diadia.giocatore;

public class Giocatore {
	
	public int cfu;
	private Borsa bag;
	
	public Giocatore() {
		bag = new Borsa();
		
	}
	
	public Borsa getBorsa() {
		return this.bag;
	}
	
	public int getCfu() {
		return this.cfu;
	}

	public void setCfu(int cfu) {
		this.cfu = cfu;		
	}	

	
}
