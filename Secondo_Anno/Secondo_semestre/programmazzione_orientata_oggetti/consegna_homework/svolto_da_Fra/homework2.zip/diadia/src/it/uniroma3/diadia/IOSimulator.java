//package it.uniroma3.diadia;
//
//public class IOSimulator implements IO {
//private String[] ComandiUsati;
//int NumeroComandi
//	@Override
//	public void mostraMessaggio(String messaggio) {
//		// TODO Auto-generated method stub
//
//	}
//
//	@Override
//	public String leggiRiga() {
//		
//		return null;
//	}
//
//}
