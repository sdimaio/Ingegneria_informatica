package esame_2_html_lettere1;


public class Quiz {
    public static void main (String[] args) {
        X a = new Y();
        Y b = new Y();
        
        a.me();
        a.greet(b);
        a.greet(a);
    }
    
}