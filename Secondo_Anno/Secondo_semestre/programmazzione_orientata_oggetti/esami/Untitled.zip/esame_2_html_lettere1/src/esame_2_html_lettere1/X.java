package esame_2_html_lettere1;

class X {
    
    public void me(){
        System.out.println("X");
    }
    
    public void greet(X x) {
        System.out.println("greet(X)");
    }

}
