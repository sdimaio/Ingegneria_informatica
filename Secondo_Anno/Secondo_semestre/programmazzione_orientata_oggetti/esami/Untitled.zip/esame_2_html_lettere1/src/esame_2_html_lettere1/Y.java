package esame_2_html_lettere1;


class Y extends X {
    @Override
    public void me(){
        System.out.println("Y");
    }
    
    public void greet(Y y) {
        System.out.println("greet(Y)");
    } 
    
}
