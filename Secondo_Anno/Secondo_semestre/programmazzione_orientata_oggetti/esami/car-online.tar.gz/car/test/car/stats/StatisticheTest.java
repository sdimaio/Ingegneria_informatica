package car.stats;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class StatisticheTest {

	private Statistiche stats;

	@Before
	public void setUp() {
		this.stats = new Statistiche();
	}
	
	@Test
	public void testTragittoPerAuto() {
		// DA COMPLETARE ( VEDI DOMANDA 3 )
		fail("DA COMPLETARE");
	}

}
